/* ==========================================================================
   Javascript Type Checkers

   Various utility functions to check Javascript types and primitives.

   Contains code copied from with moderate modifications:

   https://github.com/angular/angular.js/blob/master/src/Angular.js.
   Copyright (c) 2010-2015 Google, Inc. http://angularjs.org

   ========================================================================== */

const _toString = Object.prototype.toString;

/**
 * @name isUndefined
 * @kind function
 * @description
 * Determines if a reference is undefined.
 * @param {unknown} value - Reference to check.
 * @returns {boolean} True if `value` is undefined.
 */
function isUndefined(value) {
  return typeof value === 'undefined';
}

/**
 * @name isDefined
 * @kind function
 * @description
 * Determines if a reference is defined.
 * @param {unknown} value - Reference to check.
 * @returns {boolean} True if `value` is defined.
 */
function isDefined(value) {
  return typeof value !== 'undefined';
}

/**
 * @name isObject
 * @kind function
 * @description
 * Determines if a reference is an `Object`.
 * Unlike `typeof` in JavaScript, `null`s are not
 * considered to be objects. Note that JavaScript arrays are objects.
 * @param {unknown} value - Reference to check.
 * @returns {boolean} True if `value` is an `Object` but not `null`.
 */
function isObject(value) {
  // http://jsperf.com/isobject4
  return value !== null && typeof value === 'object';
}

/**
 * @name isString
 * @kind function
 * @description
 * Determines if a reference is a `String`.
 * @param {unknown} value - Reference to check.
 * @returns {boolean} True if `value` is a `String`.
 */
function isString(value) {
  return _toString.call(value) === '[object String]';
}

/**
 * @name isNumber
 * @kind function
 * @description
 * Determines if a reference is a `Number`.
 *
 * This includes the "special" numbers `NaN`, `+Infinity` and `-Infinity`.
 *
 * If you wish to exclude these then you can use the native
 * [`isFinite'](https://developer.mozilla.org/en-US/docs/Web/JavaScript/
 *                      Reference/Global_Objects/isFinite)
 * method.
 * @param {unknown} value - Reference to check.
 * @returns {boolean} True if `value` is a `Number`.
 */
function isNumber(value) {
  return _toString.call(value) === '[object Number]';
}

/**
 * @name isDate
 * @kind function
 * @description
 * Determines if a value is a date.
 * @param {unknown} value - Reference to check.
 * @returns {boolean} True if `value` is a `Date`.
 */
function isDate(value) {
  return _toString.call(value) === '[object Date]';
}

/**
 * @name isArray
 * @kind function
 * @description
 * Determines if a reference is an `Array`.
 * @param {unknown} value - Reference to check.
 * @returns {boolean} True if `value` is an `Array`.
 */
const isArray =
  Array.isArray ||
  function isArray(value) {
    return _toString.call(value) === '[object Array]';
  };

/**
 * @name isFunction
 * @kind function
 * @description
 * Determines if a reference is a `Function`.
 * @param {unknown} value - Reference to check.
 * @returns {boolean} True if `value` is a `Function`.
 */
function isFunction(value) {
  return _toString.call(value) === '[object Function]';
}

// TODO Fix complexity issue

/**
 * @name isEmpty
 * @kind function
 * @description
 * Determines if a reference is empty.
 * @param {unknown} value - Reference to check.
 * @returns {boolean} True if `value` is empty.
 */
function isEmpty(value) {
  return (
    isUndefined(value) ||
    value === null ||
    (isString(value) && value.length <= 0) ||
    /^\s*$/.test(value)
  );
}

// Expose public methods.
export {
  isUndefined,
  isDefined,
  isObject,
  isString,
  isNumber,
  isDate,
  isArray,
  isFunction,
  isEmpty,
};
